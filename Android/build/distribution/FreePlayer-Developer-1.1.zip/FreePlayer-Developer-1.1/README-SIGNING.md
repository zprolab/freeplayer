# FreePlayer 开发者内部包（v1.1）

FreePlayer Android 客户端源码开发包，包含 release 签名密钥。

## 内容

- `Android/` — Android 客户端源码（Kotlin + Compose）
- `macos/` — macOS 版源码（Swift，参考实现）
- `src/`、`shell/` — 旧 Web 版（历史参考）
- `docs/FreePlayer/` — 主版本（Web）源码参考

## Release 签名

| 项 | 值 |
|---|---|
| 密钥文件 | `Android/build/distribution/freeplayer-release.jks` |
| Key Alias | `freeplayer` |
| Store 密码 | `FreePlayer-Release-2026` |
| Key 密码 | `FreePlayer-Release-2026` |
| 证书 | CN=FreePlayer, OU=ZProLab, O=ZProLab, C=CN |

Gradle 签名配置从 `Android/keystore.properties` 读取（该文件在 git 中已被忽略，防止密码入库）。

## 构建

```bash
cd Android
./gradlew :app:assembleRelease    # 发布 APK（已签名）
./gradlew :app:testDebugUnitTest  # 单元测试
```

发布产物：`Android/app/build/outputs/apk/release/app-release.apk`

## 版本

- 当前：1.1（versionCode 2）
- 升级请保持同一签名密钥，否则覆盖安装会失败

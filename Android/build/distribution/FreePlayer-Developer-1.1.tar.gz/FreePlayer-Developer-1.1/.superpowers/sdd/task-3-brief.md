### Task 3: Push playback state from renderer to main

**Files:**
- Modify: `src/hooks/usePlayback.js`

**Interfaces:**
- Consumes: `window.freeplayer.sendPlaybackState(isPlaying)` (from Task 2)
- Produces: Playback state pushed to main process whenever `isPlaying` changes

- [ ] **Step 1: Add playback state push effect**

In `src/hooks/usePlayback.js`, find the existing media key effect at line ~197. Add this new effect **before** the media key effect, after the unmount cleanup effect:

```js
  // Push playback state to main process for tray menu
  useEffect(() => {
    window.freeplayer?.sendPlaybackState(state.isPlaying);
  }, [state.isPlaying]);
```

Note: `state` is already available from `usePlayer()` at the top of the hook (line 15). The `?.` guards against the case where `window.freeplayer` is not yet available (extremely rare since preload runs first, but defensive).

- [ ] **Step 2: Commit**

```bash
cd /Users/eason/Documents/Coding/hi-zcy/FreePlayer
git add src/hooks/usePlayback.js
git commit -m "feat: push playback state to main for tray menu label"
```

---


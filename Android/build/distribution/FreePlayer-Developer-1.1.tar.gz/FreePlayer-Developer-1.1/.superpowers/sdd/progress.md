Task 1: complete (commits 60242b3..634f9d0, review: spec ✅ — Cmd+Q fix applied)
Task 2: complete (commits 634f9d0..ab1d596, review clean)
Task 3: complete (commits ab1d596..1232123, review clean)
Task 4: complete (commits 1232123..eb998e1, review: clean, cleanup gap is existing pattern)
Task 5: complete (commits eb998e1..5511efb, review clean)
Task 6: complete (code-level verification: all IPC channels consistent, 6 files, 237 lines)
Final fixes: IPC listener leak (ref pattern) + macOS dock restore

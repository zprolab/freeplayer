### Task 4: Handle tray control commands in App

**Files:**
- Modify: `src/App.jsx`

**Interfaces:**
- Consumes: `window.freeplayer.onPlaybackControl` (from Task 2), `togglePlayPause`, `handleNext`, `handlePrev` (from `usePlayback`)
- Produces: Tray menu play/pause/prev/next commands dispatched to playback handlers

- [ ] **Step 1: Add tray control listener effect**

In `src/App.jsx`, after the keyboard shortcuts effect (~line 59) and before the drag-and-drop handlers, add:

```js
  // Tray menu playback control
  React.useEffect(() => {
    if (!window.freeplayer?.onPlaybackControl) return;
    const handler = ({ action }) => {
      switch (action) {
        case 'playpause': togglePlayPause(); break;
        case 'next': handleNext(); break;
        case 'previous': handlePrev(); break;
      }
    };
    window.freeplayer.onPlaybackControl(handler);
  }, [togglePlayPause, handleNext, handlePrev]);
```

- [ ] **Step 2: Commit**

```bash
cd /Users/eason/Documents/Coding/hi-zcy/FreePlayer
git add src/App.jsx
git commit -m "feat: handle tray menu playback control commands"
```

---


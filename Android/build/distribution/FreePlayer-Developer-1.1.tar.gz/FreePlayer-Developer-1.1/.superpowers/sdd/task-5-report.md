# Task 5: Add tray setting toggle to Settings page

**Status:** Complete

## Changes Made

### 1. `src/components/Settings.jsx`
- Added `trayEnabled` local state (initialised to `true`) after `showResetConfirm`
- Added `useEffect` to load persisted `tray_enabled` setting from the database on mount, with flexible truthy parsing (`true`, `'true'`, `1`, `'1'`)
- Added a new `playback-row` for "Close to Tray" between the Default Visualizer row and the Playback section's closing `</div>`, containing a toggle switch that writes back to the database via `window.freeplayer.setSetting`

### 2. `src/App.css`
- Added `.toggle-switch`, `.toggle-slider`, and `:checked+` rules for the standard switch appearance (44x24px track, 18x22px knob, indigo `#6366f1` when checked, smooth `0.2s` transitions)

## Commits

```
5511efb feat: add close-to-tray toggle in Settings
```

2 files changed, 70 insertions(+)

## Verification

- Code structure matches the task brief exactly
- State sourced from DB on mount with graceful fallback to `true`
- Toggle writes `tray_enabled` to DB immediately on change
- CSS is appended at end of `App.css` (no collisions with existing selectors)

### Task 2: Add preload bridge methods

**Files:**
- Modify: `electron/preload.js`

**Interfaces:**
- Consumes: (none — independent of Task 1)
- Produces:
  - `window.freeplayer.sendPlaybackState(isPlaying)` — calls `ipcRenderer.send('playback:state-changed', { isPlaying })`
  - `window.freeplayer.onPlaybackControl(callback)` — listens for `playback:control` from main, calls `callback({ action })`

- [ ] **Step 1: Add the two bridge methods**

In `electron/preload.js`, add inside the `contextBridge.exposeInMainWorld('freeplayer', {` object, before the closing `});` on line 56:

```js
  // Tray playback state push
  sendPlaybackState: (isPlaying) => ipcRenderer.send('playback:state-changed', { isPlaying }),

  // Tray menu control listener
  onPlaybackControl: (callback) => {
    ipcRenderer.on('playback:control', (_event, data) => callback(data));
  },
```

- [ ] **Step 2: Commit**

```bash
cd /Users/eason/Documents/Coding/hi-zcy/FreePlayer
git add electron/preload.js
git commit -m "feat: add preload bridge for tray playback state and control"
```

---


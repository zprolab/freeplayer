### Task 5: Add tray setting toggle to Settings page

**Files:**
- Modify: `src/components/Settings.jsx`

**Interfaces:**
- Consumes: `window.freeplayer.getSetting('tray_enabled')`, `window.freeplayer.setSetting({ key: 'tray_enabled', value })`
- Produces: Toggle switch in Settings UI, persisted to DB

- [ ] **Step 1: Add local state and load on mount**

At the top of the `Settings` component function, after the `showResetConfirm` state line (~line 14):

```js
  const [trayEnabled, setTrayEnabled] = useState(true); // default true
```

Add a useEffect to load the saved value:

```js
  React.useEffect(() => {
    window.freeplayer.getSetting('tray_enabled').then(val => {
      if (val !== undefined && val !== null) {
        setTrayEnabled(val === true || val === 'true' || val === 1 || val === '1');
      }
    }).catch(() => {});
  }, []);
```

- [ ] **Step 2: Add tray toggle UI in the Playback section**

Inside the Playback settings section (`<div className="settings-section">` that contains the Playback header), after the Default Visualizer row (after its closing `</div>`), add:

```jsx
          <div className="playback-row">
            <div className="playback-label-group">
              <span className="playback-label">Close to Tray</span>
              <span className="playback-hint">Minimize to system tray instead of quitting when closing the window</span>
            </div>
            <label className="toggle-switch">
              <input
                type="checkbox"
                checked={trayEnabled}
                onChange={(e) => {
                  const val = e.target.checked;
                  setTrayEnabled(val);
                  window.freeplayer.setSetting({ key: 'tray_enabled', value: val });
                }}
              />
              <span className="toggle-slider" />
            </label>
          </div>
```

- [ ] **Step 3: Add toggle CSS styles**

In `src/App.css`, add at the end:

```css
/* Toggle Switch */
.toggle-switch {
  position: relative;
  display: inline-block;
  width: 44px;
  height: 24px;
  flex-shrink: 0;
}
.toggle-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.toggle-slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(255,255,255,0.15);
  border-radius: 12px;
  transition: background-color 0.2s;
}
.toggle-slider::before {
  content: "";
  position: absolute;
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  border-radius: 50%;
  transition: transform 0.2s;
}
.toggle-switch input:checked + .toggle-slider {
  background-color: #6366f1;
}
.toggle-switch input:checked + .toggle-slider::before {
  transform: translateX(20px);
}
```

- [ ] **Step 4: Commit**

```bash
cd /Users/eason/Documents/Coding/hi-zcy/FreePlayer
git add src/components/Settings.jsx src/App.css
git commit -m "feat: add close-to-tray toggle in Settings"
```

---


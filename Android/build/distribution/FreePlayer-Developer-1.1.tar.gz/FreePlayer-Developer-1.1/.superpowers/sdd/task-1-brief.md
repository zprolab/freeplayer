### Task 1: Add tray logic to Electron main process

**Files:**
- Modify: `electron/main.js`

**Interfaces:**
- Consumes: (none — first task)
- Produces:
  - Tray created with context menu
  - `mainWindow.on('close')` intercepted — hides window when `tray_enabled` is true
  - IPC handler `playback:state-changed` updates tray menu Play/Pause label
  - Tray menu actions sent to renderer via `webContents.send('playback:control', { action })`

- [ ] **Step 1: Add Tray and Menu to Electron imports**

In `electron/main.js`, line 1, update the destructured require:

```js
const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, dialog, protocol, globalShortcut } = require('electron');
```

- [ ] **Step 2: Add state variables and tray icon generator**

Add after the `let mainWindow;` line (~line 37), before `createWindow`:

```js
let mainWindow;
let tray = null;
let isQuitting = false;

// Generate a 16x16 tray icon programmatically — a simple musical note shape.
// No external asset file needed. Replace with a custom .png if desired.
function createTrayIcon() {
  // 16x16 musical note pixel art: '#' = white, '.' = transparent
  const note = [
    '................',
    '................',
    '.....##.........',
    '....#.#.........',
    '....##..........',
    '....##..........',
    '....#.#.........',
    '....##..........',
    '....##..........',
    '....##..........',
    '....##..........',
    '...####.........',
    '...##.##........',
    '..##..##........',
    '................',
    '................',
  ];
  const size = 16;
  const buffer = Buffer.alloc(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      if (note[y][x] === '#') {
        buffer[idx] = 0xff;     // R
        buffer[idx + 1] = 0xff; // G
        buffer[idx + 2] = 0xff; // B
        buffer[idx + 3] = 0xff; // A
      } else {
        buffer[idx] = 0x1f;     // R
        buffer[idx + 1] = 0x1f; // G
        buffer[idx + 2] = 0x23; // B (background #1f1f23)
        buffer[idx + 3] = 0xff; // A
      }
    }
  }
  return nativeImage.createFromBuffer(buffer, { width: size, height: size });
}
```

- [ ] **Step 3: Create the tray with context menu**

Add a new function `createTray()` after `createWindow()`:

```js
function createTray() {
  const icon = createTrayIcon();
  tray = new Tray(icon);
  tray.setToolTip('FreePlayer');

  const updateMenu = (isPlaying) => {
    const contextMenu = Menu.buildFromTemplate([
      {
        label: 'Show Window',
        click: () => {
          mainWindow.show();
          mainWindow.focus();
        },
      },
      { type: 'separator' },
      {
        label: isPlaying ? 'Pause' : 'Play',
        click: () => {
          mainWindow.webContents.send('playback:control', { action: 'playpause' });
        },
      },
      {
        label: 'Previous Track',
        click: () => {
          mainWindow.webContents.send('playback:control', { action: 'previous' });
        },
      },
      {
        label: 'Next Track',
        click: () => {
          mainWindow.webContents.send('playback:control', { action: 'next' });
        },
      },
      { type: 'separator' },
      {
        label: 'Quit FreePlayer',
        click: () => {
          isQuitting = true;
          app.quit();
        },
      },
    ]);
    tray.setContextMenu(contextMenu);
  };

  // Initial menu (assume paused)
  updateMenu(false);

  // Double-click tray icon → show window
  tray.on('double-click', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Store updateMenu for use in IPC handler
  tray._updateMenu = updateMenu;
}
```

- [ ] **Step 4: Add close interception to `createWindow`**

Inside `createWindow()`, after the window is created (after the if/else block for loading URL), add:

```js
  // Intercept close — hide to tray if tray_enabled, otherwise quit
  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      const trayEnabled = getSetting('tray_enabled', true);
      if (trayEnabled) {
        event.preventDefault();
        mainWindow.hide();
        return;
      }
    }
    // Clean up tray when actually closing
    if (tray) {
      tray.destroy();
      tray = null;
    }
  });
```

- [ ] **Step 5: Call `createTray()` after `createWindow()` in app startup**

In the `app.whenReady()` block (~line 554), add `createTray();` after `createWindow();`:

```js
  createWindow();
  createTray();
```

- [ ] **Step 6: Add `playback:state-changed` IPC handler**

In the `setupIPC()` function, add before the closing `}` of the function:

```js
  // Playback state from renderer → update tray menu label
  ipcMain.on('playback:state-changed', (_event, { isPlaying }) => {
    if (tray && tray._updateMenu) {
      tray._updateMenu(isPlaying);
    }
  });
```

- [ ] **Step 7: Update `app.on('window-all-closed')` to destroy tray**

Replace the existing handler (~line 583):

```js
app.on('window-all-closed', () => {
  globalShortcut.unregisterAll();
  if (tray) {
    tray.destroy();
    tray = null;
  }
  closeDatabase();
  if (process.platform !== 'darwin') app.quit();
});
```

- [ ] **Step 8: Verify linting**

Run:

```bash
cd /Users/eason/Documents/Coding/hi-zcy/FreePlayer && node -e "require('./electron/main.js')" 2>&1 | head -5
```

Expected: No syntax errors (may show "app.whenReady is not a function" in plain Node — that's fine, we're checking syntax only).

- [ ] **Step 9: Commit**

```bash
cd /Users/eason/Documents/Coding/hi-zcy/FreePlayer
git add electron/main.js
git commit -m "feat: add system tray with close-to-tray and playback controls"
```

---

